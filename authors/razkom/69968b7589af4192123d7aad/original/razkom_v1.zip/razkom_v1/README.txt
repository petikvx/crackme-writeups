
		CrackMe v1.1 by RAZKOM

Find a valid license key to decrypt the hidden message.

The intended solution is to reverse engineer the key validation
algorithm and either:
  a) Find a valid key manually
  b) Write a keygen that generates valid keys

Patching the binary will NOT reveal the secret message.

- No network connections are made
- No files are written to disk
- No system modifications are made
- Safe to run in a VM or sandbox