this is simple rsa-64 crackme
patching is not solution
Find the correct serial